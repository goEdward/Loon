# 小米电视用户
miTV.txt 引用地址
```
https://github.com/blackmatrix7/ios_rule_script/blob/master/rule/QuantumultX/AdvertisingMiTV/AdvertisingMiTV.list
```
miTVLite.txt 为自用版本
## 如何使用
1. 删除设备内名为 miad 的目录
2. 通过路由器 host 指定域名所对应的 ip 地址
# iOS 用户
通过安装 noota.mobileconfig 文件来屏蔽更新
