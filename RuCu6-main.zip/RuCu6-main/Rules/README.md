# 引用地址 - MyBlockAds.list
```
https://github.com/blackmatrix7/ios_rule_script/blob/release/rule/QuantumultX/ZhihuAds/ZhihuAds.list
https://github.com/ddgksf2013/Cuttlefish/blob/master/Filter/MyAdRule.list
https://github.com/ddgksf2013/Cuttlefish/blob/master/Filter/Mybreak.list
https://github.com/app2smile/rules/tree/master/rule
```
